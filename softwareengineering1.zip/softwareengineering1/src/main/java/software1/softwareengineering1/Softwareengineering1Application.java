package software1.softwareengineering1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Softwareengineering1Application {

	public static void main(String[] args) {
		SpringApplication.run(Softwareengineering1Application.class, args);


	}

}
