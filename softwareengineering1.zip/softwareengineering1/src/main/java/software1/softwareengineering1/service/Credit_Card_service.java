package software1.softwareengineering1.service;

import org.springframework.stereotype.Service;
import software1.softwareengineering1.entity.Credit_Card;
import software1.softwareengineering1.entity.profile_of_user;

import java.util.List;

@Service
public interface Credit_Card_service {

    public Credit_Card update_profile_Credit_Card(String user_name_fk_variable, Credit_Card user_card);

    public void delete_user_CC(String user_delete_CC);

    public Credit_Card Save_user_CC(Credit_Card save_user_CC);

    public List<Credit_Card> fetchingListOfCC();

    public Credit_Card fetchingListByID_CC(String user_CC);


}
