package net.codejava.BookREST;

public class book_implementations {

}
