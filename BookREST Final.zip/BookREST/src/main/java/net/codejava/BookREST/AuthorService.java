package net.codejava.BookREST;

public interface AuthorService {

	Author save_author(Author author);

}
