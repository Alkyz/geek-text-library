package net.codejava.BookREST;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
/*
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
*/

@SpringBootApplication
public class BookRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookRestApplication.class, args);
	}
	
	/*
	@Bean
	CommandLineRunner commandLineRunner(UserRepository users) {
		return args -> {
			users.save(new TestUser(null, "user", "password", "ROLE_USER"));
			users.save(new TestUser(null, "admin", "password", "ROLE_USER,ROLE_ADMIN"));
		};
		
	}
	
	@SuppressWarnings("deprecation")
	@Bean
	PasswordEncoder passwordEncoder() {
		return NoOpPasswordEncoder.getInstance();
	}
	*/
}
