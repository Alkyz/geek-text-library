package net.codejava.BookREST;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
/*
public interface UserRepository extends CrudRepository<TestUser, Long> {

	Optional<TestUser> findByUsername(String username);

}
*/