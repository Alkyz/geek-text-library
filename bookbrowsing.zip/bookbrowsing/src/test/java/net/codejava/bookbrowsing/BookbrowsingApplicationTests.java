package net.codejava.bookbrowsing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookbrowsingApplicationTests {

	@Test
	void contextLoads() {
	}

}
