package com.alkyz.ratingcommenting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class RatingCommentingApplication {

    public static void main(String[] args) {
        SpringApplication.run(RatingCommentingApplication.class, args);
    }
}
