package com.alkyz.ratingcommenting.RatingInfo;

public class RatingException extends Exception {
    public RatingException (String errorMessage) {
        super(errorMessage);
    }
}
