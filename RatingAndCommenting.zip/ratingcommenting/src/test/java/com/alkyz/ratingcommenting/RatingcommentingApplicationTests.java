package com.alkyz.ratingcommenting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RatingcommentingApplicationTests {

    @Test
    void contextLoads() {
    }

}
